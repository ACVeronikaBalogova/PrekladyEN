---
author: edupont04


ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---
You can set up an unlimited number of reminder terms. Each set of terms is identified by a code. Each reminder term has predefined reminder levels. Each reminder level includes rules about when the reminder will be issued, for example, how many days after the invoice due date or the date of the previous reminder.
