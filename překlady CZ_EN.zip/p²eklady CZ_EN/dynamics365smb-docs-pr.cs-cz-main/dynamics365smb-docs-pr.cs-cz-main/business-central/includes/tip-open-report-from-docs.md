---
author: edupont04


ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---

> [!TIP]
> If you have a (online) [!INCLUDE [prod_short](prod_short.md)] production environment, you can click on a report id below to open the report directly in the product. If you want to stay on this page, consider holding down CTRL before clicking. In most browsers, the report will then open in a new browser tab. 