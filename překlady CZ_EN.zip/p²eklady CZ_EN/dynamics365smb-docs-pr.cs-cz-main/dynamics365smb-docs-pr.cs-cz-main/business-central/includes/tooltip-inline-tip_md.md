Chcete-li si přečíst krátký popis, umístěte ukazatel myši na pole.
