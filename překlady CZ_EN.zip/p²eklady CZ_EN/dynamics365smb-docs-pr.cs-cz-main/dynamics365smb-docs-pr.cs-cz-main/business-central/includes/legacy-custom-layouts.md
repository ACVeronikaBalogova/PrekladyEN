> [!NOTE]
> Custom report layouts is a legacy feature that is being phased out. Instead, you should start creating user-defined layouts as described [here](../ui-get-started-layouts.md).