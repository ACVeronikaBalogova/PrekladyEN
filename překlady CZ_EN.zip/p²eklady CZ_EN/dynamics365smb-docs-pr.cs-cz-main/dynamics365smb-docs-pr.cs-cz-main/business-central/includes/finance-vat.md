---
author: edupont04

ms.topic: include
ms.date: 12/28/2021
ms.author: edupont
---
> [!TIP]
> [!INCLUDE [prod_short](prod_short.md)] is available in countries that do not use VAT. For information about how to set up and report tax in your particular country, see the articles in the [Local Functionality](../about-localization.md) section.  
