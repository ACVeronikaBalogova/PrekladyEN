> [!IMPORTANT]
>
> Zajímají Vás nadcházející a nedávno vydané funkce v Dynamics 365 Business Central?
>
> [Podívejte se na nejnovější verzi plánu vydání](/dynamics365/release-plans/index). Zaznamenali jsme všechny podrobnosti, od začátku do konce, které můžete použít pro plánování. Pro každou verzi můžete získat plán vydání jako jeden soubor PDF.