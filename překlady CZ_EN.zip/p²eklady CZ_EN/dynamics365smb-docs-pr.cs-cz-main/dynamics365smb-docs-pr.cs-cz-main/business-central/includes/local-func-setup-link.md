> [!IMPORTANT]
> V závislosti na vaší zemi nebo regionu může být nutné další nastavení. Další informace naleznete v seznamu souvisejících článků v části [Viz také](#see-also).