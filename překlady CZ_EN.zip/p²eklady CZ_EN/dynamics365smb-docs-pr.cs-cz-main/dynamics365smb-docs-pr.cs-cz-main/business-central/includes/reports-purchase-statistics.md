---
author: edupont04

ms.topic: include
ms.date: 07/13/2021
ms.author: edupont
---
Shows purchase statistics for each vendor. This includes information for five periods, starting on the date that you specify.<br>The report includes the total purchases, payments, finance charges, and discount information including the payment discounts taken and lost. Statistics are calculated for purchases before the date entered, at three one-month intervals from the date entered, and for a period including all purchases made after the third one-month interval.