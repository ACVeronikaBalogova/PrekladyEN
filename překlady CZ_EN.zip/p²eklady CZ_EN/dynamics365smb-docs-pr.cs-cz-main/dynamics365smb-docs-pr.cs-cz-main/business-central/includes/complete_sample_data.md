---
author: edupont04


ms.topic: include
ms.date: 02/17/2022
ms.author: edupont
---
> [!NOTE]
> This walkthrough requires sample data that is not available in the default demonstration company in [!INCLUDE[prod_short](prod_short.md)]. If you install the Contoso Coffee app, you'll have access to demonstration data that can support the walkthrough, but the names of products are different.<!--For more information, see [To create a company with complete sample data in a sandbox](../admin-sandbox-environments.md#to-create-a-company-with-complete-sample-data-in-a-sandbox).  
 -->
