Můžete změnit způsob zobrazení určitých prvků uživatelského rozhraní. Další informace viz [Přizpůsobení pracovního prostoru](../ui-personalization-user.md).
