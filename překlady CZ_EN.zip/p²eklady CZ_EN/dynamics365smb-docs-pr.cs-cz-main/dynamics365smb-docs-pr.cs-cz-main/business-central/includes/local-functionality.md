---
author: edupont04

ms.topic: include
ms.date: 06/14/2021
ms.author: edupont
---
> [!TIP]
> The articles in this section describe built-in capabilities in the default version of [!INCLUDE [prod_short](prod_short.md)]. Your [!INCLUDE [prod_short](prod_short.md)] may include additional fields on the various pages to be compliant with regulations in your country or region, for example. [!INCLUDE [tooltip-inline-tip_md](tooltip-inline-tip_md.md)] Find information about built-in regulatory capabilities in the [Local Functionality](../about-localization.md) section.