Získejte [školení!](/learn/browse/?products=dynamics-business-central)
