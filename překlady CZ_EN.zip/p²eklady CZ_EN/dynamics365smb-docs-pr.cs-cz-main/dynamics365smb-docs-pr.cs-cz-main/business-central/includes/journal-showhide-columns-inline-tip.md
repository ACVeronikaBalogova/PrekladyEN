---
author: ZdenekBicek
ms.service: dynamics365-business-central  
ms.topic: include
ms.date: 10/01/2019
ms.reviewer: v-zdbice
ms.author: edupont
---
Finanční deník ve výchozím nastavení zobrazuje na řádku deníku pouze omezený počet polí. Pokud chcete vidět další pole, například pole **Typ účtu**, vyberte akci **Zobrazit více sloupců**. Chcete-li další pole znovu skrýt, vyberte akci **Zobrazit méně sloupců**. Pokud uvidíte méně sloupců, použije se pro všechny řádky stejné datum účtování. Pokud chcete mít pro stejnou položku deníku více zúčtovacích dat , vyberte akci **Zobrazit více sloupců**.
