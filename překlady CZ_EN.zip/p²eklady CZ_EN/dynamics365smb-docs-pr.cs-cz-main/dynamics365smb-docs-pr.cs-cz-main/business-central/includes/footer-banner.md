---
author: edupont04

ms.topic: include
ms.date: 08/02/2022
ms.author: edupont
---
[Find free e-learning modules for Business Central here](/learn/dynamics365/business-central)

## Help us understand

We want to learn more about how people use Microsoft's [custom Help toolkit](https://github.com/microsoft/dynamics365smb-custom-help). Take the survey (in English) and help us understand: [https://forms.office.com/r/A4cUJgjkD1](https://forms.office.com/r/A4cUJgjkD1).  


