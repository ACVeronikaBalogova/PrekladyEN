---
author: edupont04

ms.topic: include
ms.date: 03/21/2022
ms.author: edupont
---
> **APPLIES TO:** Business Central 2022 release wave 2 and later