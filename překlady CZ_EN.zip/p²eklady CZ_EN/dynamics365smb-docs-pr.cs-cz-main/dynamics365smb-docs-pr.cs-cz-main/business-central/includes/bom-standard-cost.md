---
author: edupont04


ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---
To calculate the unit cost of an assembly or production BOM, the parent item and its component items must use the *Standard* costing method. Any resources in the BOM are rolled up if they have a unit cost that is defined on the resource card.
