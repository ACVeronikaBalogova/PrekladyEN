---
author: edupont04

ms.topic: include
ms.date: 10/01/2021
ms.author: edupont
---
> **APPLIES TO:** Business Central 2021 release wave 2 and later