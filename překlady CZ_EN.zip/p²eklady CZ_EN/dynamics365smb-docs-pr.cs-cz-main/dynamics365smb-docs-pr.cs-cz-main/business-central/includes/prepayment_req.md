---
author: edupont04

ms.topic: include
ms.date: 12/03/2021
ms.author: edupont
---
For each customer or vendor, you can define prepayment requirements for all items or selected items. When you've set up prepayments, you can then generate prepayment invoices from sales and purchase orders with prepayment amounts that are based on your setup. You can change the amounts on the invoice as needed.  
