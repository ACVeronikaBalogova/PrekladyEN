---
author: edupont04

ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---
The **Get started** checklist can help you set up key information.  
