---
author: edupont04

ms.topic: include
ms.date: 11/25/2021
ms.author: edupont
---
Your implementation may differ.  
