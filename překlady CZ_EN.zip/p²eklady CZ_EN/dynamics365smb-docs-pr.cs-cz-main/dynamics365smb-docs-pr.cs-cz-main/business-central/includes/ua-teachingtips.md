---
author: edupont04

ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---
Some pages display a teaching tip with a short introduction to the page. Switch off teaching tips if you are not interested in seeing these short introductions when you open the relevant pages. If you switch off teaching tips, you can still open the teaching tip for a specific page by choosing the page title in the top left corner.  
