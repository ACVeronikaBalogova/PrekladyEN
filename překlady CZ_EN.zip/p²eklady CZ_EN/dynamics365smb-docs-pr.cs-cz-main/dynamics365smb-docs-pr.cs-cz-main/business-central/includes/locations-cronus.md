---
author: edupont04


ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---
This article uses names of locations from an earlier version of the demonstration company in [!INCLUDE [prod_short](prod_short.md)]. These names do not map directly to the locations in the current demonstration company. We encourage you to use the article to learn about locations and not as step-by-step instructions for how to use the demonstration company.