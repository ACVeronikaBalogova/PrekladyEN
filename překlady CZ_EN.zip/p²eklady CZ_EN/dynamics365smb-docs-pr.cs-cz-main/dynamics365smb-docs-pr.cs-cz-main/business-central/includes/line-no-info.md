---
author: edupont04


ms.topic: include
ms.date: 04/01/2021
ms.author: edupont
---
> [!TIP]
> In the default version of [!INCLUDE [prod_short](prod_short.md)], line numbers are hidden. If you want to see the line numbers, you must personalize the current page and add the **Line No.** field. For more information, see [Personalize Your Workspace](../ui-personalization-user.md#to-start-personalizing-a-page-through-the-personalizing-banner).  
