---
author: edupont04

ms.topic: include
ms.date: 02/21/2022
ms.author: edupont
---
> [!NOTE]
> If a [!INCLUDE [prod_short](prod_short.md)] trial is left unused for 45 days, Microsoft considers the trial as expired, and the [!INCLUDE [prod_short](prod_short.md)] tenant is deleted.
>
> If the trial is converted to a paid subscription before the trial expires, the countdown to 45 days of non-usage does not apply.
