---
author: edupont04

ms.topic: include
ms.date: 04/28/2022
ms.author: edupont
---
> [!TIP]
> Take free e-learning content about the [!INCLUDE [prod_short](prod_short.md)] user interface on [Microsoft Learn](/learn/dynamics365/business-central?WT.mc_id=dyn365bc_landingpage-docs). 
